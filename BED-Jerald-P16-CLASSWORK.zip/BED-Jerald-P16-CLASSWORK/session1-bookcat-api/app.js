const express = require('express');
const app = express();

app.get('/', (req, res) => {
  res.send('Welcome to the Book Category API');
});

app.get('/categories', (req, res) => {
  res.json([
    { id: 1, name: 'Fiction' },
    { id: 2, name: 'Non-Fiction' },
    { id: 3, name: 'Biography' }
  ]);
});

app.get('/about', (req, res) => {
  res.send('Hi, my name is Jerald. I am a Year 1 IT student at Ngee Ann Polytechnic. I am learning how to build backend applications using Node.js and Express.');
});

app.listen(3000, () => {
  console.log('Listening on port 3000');
});
